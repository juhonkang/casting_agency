# Quick Deployment Fix

## Problem
Render was using Python 3.13.4 (incompatible with SQLAlchemy 2.0.21) instead of Python 3.11.5.

## Solution
I've fixed the configuration files. Now you need to:

### Step 1: Commit and Push the Fixes

```bash
cd C:\Users\juhon\Downloads\casting_agency

# Stage all changes
git add .

# Commit the fixes
git commit -m "Fix Render deployment configuration"

# Push to GitHub
git push origin main
```

### Step 2: Trigger Redeploy on Render

**Option A: Automatic (Recommended)**
- Render should automatically detect the push and redeploy
- Go to your Render dashboard
- Watch the deployment logs
- It should work now!

**Option B: Manual Redeploy**
1. Go to Render Dashboard
2. Click on your "trivia-api" service
3. Click "Manual Deploy" → "Deploy latest commit"
4. Wait for build to complete

### Step 3: Verify Environment Variables

In Render Dashboard → trivia-api → Environment:

Make sure these are set:
```
AUTH0_DOMAIN=dev-8607typd5q1j6mig.us.auth0.com
ALGORITHMS=["RS256"]
API_AUDIENCE=trivia-api
FLASK_ENV=production
DATABASE_URL=[should be auto-set from database]
```

### Step 4: Test Your Deployed API

Once deployment succeeds, test it:

```bash
# Replace YOUR_RENDER_URL with your actual Render URL
export RENDER_URL="https://trivia-api-xxxx.onrender.com"

# Test 1: Should fail without auth
curl $RENDER_URL/questions

# Test 2: Should work with auth (replace with your token)
curl $RENDER_URL/questions \
  -H "Authorization: Bearer YOUR_TRIVIA_USER_TOKEN"
```

## What Was Fixed

1. **Created `render.yaml` in project root** - Render needs it at root level
2. **Added `rootDir: backend`** - Tells Render where Python app is located
3. **Specified Python 3.11.5** - Via PYTHON_VERSION env var
4. **Added your Auth0 domain** - dev-8607typd5q1j6mig.us.auth0.com
5. **Created root-level `Procfile`** - For Heroku compatibility

## Expected Deployment Log (Success)

```
==> Using Python version 3.11.5
==> Running build command 'pip install -r requirements.txt'...
Successfully installed Flask-2.3.3 SQLAlchemy-2.0.21 [...]
==> Build successful 🎉
==> Deploying...
==> Running 'gunicorn 'flaskr:create_app()''
[INFO] Starting gunicorn 21.2.0
[INFO] Listening at: http://0.0.0.0:10000
==> Your service is live 🎉
```

## Next Steps

Once deployed successfully:

1. Get your live URL from Render
2. Test the API endpoints
3. Update README.md with the live URL:
   ```markdown
   ## Live Demo

   **API Base URL:** https://trivia-api-xxxx.onrender.com
   ```

4. Test authentication:
   ```bash
   curl https://your-app.onrender.com/questions \
     -H "Authorization: Bearer $TRIVIA_USER_TOKEN"
   ```

## If It Still Fails

Check these:

1. **Python Version in Logs**
   - Should say "Using Python version 3.11.5"
   - If not, check PYTHON_VERSION env var in Render

2. **Build Command Path**
   - Should find `requirements.txt` in backend folder
   - Check rootDir is set to "backend"

3. **Database Connection**
   - Verify DATABASE_URL is set
   - Format: `postgresql://user:pass@host/dbname`

4. **Start Command**
   - Should be: `gunicorn 'flaskr:create_app()'`
   - Working directory should be `backend/`

---

**Go ahead and push the changes now!** 🚀

```bash
git add .
git commit -m "Fix Render deployment - specify Python 3.11.5 and backend rootDir"
git push origin main
```

Then watch your Render dashboard for automatic redeploy.
