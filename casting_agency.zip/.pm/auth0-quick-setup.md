# Auth0 Quick Setup Guide

Since you've already set up the database, here's a focused guide to get Auth0 configured quickly.

## Step 1: Create Auth0 Account (5 minutes)

1. Go to **https://auth0.com**
2. Click **"Sign Up"**
3. Choose **"Sign up with GitHub"** (fastest) or use email
4. Select region: **US** (recommended) or EU
5. Verify your email
6. Complete the welcome survey (can skip)

## Step 2: Create Your API (5 minutes)

1. In Auth0 Dashboard, go to **Applications → APIs**
2. Click **"+ Create API"**
3. Fill in:
   - **Name**: `Trivia API`
   - **Identifier**: `trivia-api` ← IMPORTANT: Use exactly this
   - **Signing Algorithm**: `RS256`
4. Click **"Create"**

**✅ Save this value:**
```
API_AUDIENCE=trivia-api
```

## Step 3: Get Your Domain (1 minute)

1. In the same API page, click **"Quick Start"** tab
2. Look for the domain in the code examples
3. It will look like: `dev-abc12345.us.auth0.com`

**✅ Save this value:**
```
AUTH0_DOMAIN=dev-abc12345.us.auth0.com
```
(Replace with your actual domain - no `https://`)

## Step 4: Add Permissions (3 minutes)

1. Still in **Applications → APIs → Trivia API**
2. Click **"Permissions"** tab
3. Add these 4 permissions:

| Permission | Description |
|------------|-------------|
| `get:questions` | View trivia questions |
| `get:categories` | View question categories |
| `post:questions` | Create new questions |
| `delete:questions` | Delete questions |

For each:
- Type the permission name (e.g., `get:questions`)
- Add the description
- Click **"Add"**

## Step 5: Enable RBAC (1 minute)

1. Click **"Settings"** tab
2. Scroll to **"RBAC Settings"**
3. Toggle ON:
   - ✅ **Enable RBAC**
   - ✅ **Add Permissions in the Access Token**
4. Click **"Save"**

## Step 6: Create Roles (5 minutes)

### Role 1: Trivia User

1. Go to **User Management → Roles**
2. Click **"+ Create Role"**
3. Fill in:
   - **Name**: `Trivia User`
   - **Description**: `Basic user who can view questions and categories`
4. Click **"Create"**
5. Click **"Permissions"** tab
6. Click **"Add Permissions"**
7. Select **"Trivia API"** from dropdown
8. Check these two:
   - ✅ `get:questions`
   - ✅ `get:categories`
9. Click **"Add Permissions"**

### Role 2: Trivia Manager

1. Click **"+ Create Role"** again
2. Fill in:
   - **Name**: `Trivia Manager`
   - **Description**: `Manager with full access to questions`
3. Click **"Create"**
4. Click **"Permissions"** tab
5. Click **"Add Permissions"**
6. Select **"Trivia API"**
7. Check ALL four:
   - ✅ `get:questions`
   - ✅ `get:categories`
   - ✅ `post:questions`
   - ✅ `delete:questions`
8. Click **"Add Permissions"**

## Step 7: Create Test Users (5 minutes)

### User 1: Trivia User

1. Go to **User Management → Users**
2. Click **"+ Create User"**
3. Fill in:
   - **Email**: `trivia-user@test.com` (or your email)
   - **Password**: Create a strong password (save it!)
   - **Connection**: `Username-Password-Authentication`
4. Click **"Create"**
5. Click on the newly created user
6. Click **"Roles"** tab
7. Click **"Assign Roles"**
8. Select **"Trivia User"**
9. Click **"Assign"**

### User 2: Trivia Manager

1. Click **"+ Create User"**
2. Fill in:
   - **Email**: `trivia-manager@test.com` (or your email)
   - **Password**: Create a strong password (save it!)
   - **Connection**: `Username-Password-Authentication`
3. Click **"Create"**
4. Click on the newly created user
5. Click **"Roles"** tab
6. Click **"Assign Roles"**
7. Select **"Trivia Manager"**
8. Click **"Assign"**

## Step 8: Create Test Application (3 minutes)

We need this to generate tokens:

1. Go to **Applications → Applications**
2. Click **"+ Create Application"**
3. Fill in:
   - **Name**: `Trivia Test Client`
   - **Type**: Select **"Single Page Web Applications"**
4. Click **"Create"**
5. Go to **"Settings"** tab
6. Scroll to **"Application URIs"** section
7. Fill in:
   - **Allowed Callback URLs**: `http://localhost:3000, https://jwt.io`
   - **Allowed Logout URLs**: `http://localhost:3000`
   - **Allowed Web Origins**: `http://localhost:3000`
8. Click **"Save Changes"**
9. Copy and save:
   - **Domain** (at the top)
   - **Client ID**

## Step 9: Generate JWT Tokens (5 minutes)

### Method 1: Using Browser (Easiest)

1. Open this URL in your browser (replace YOUR_DOMAIN and YOUR_CLIENT_ID):

```
https://YOUR_DOMAIN/authorize?audience=trivia-api&response_type=token&client_id=YOUR_CLIENT_ID&redirect_uri=https://jwt.io
```

Example:
```
https://dev-abc12345.us.auth0.com/authorize?audience=trivia-api&response_type=token&client_id=xyz789&redirect_uri=https://jwt.io
```

2. **Login as Trivia User** (`trivia-user@test.com`)
3. After authorization, you'll be redirected to jwt.io
4. The URL will contain `access_token=eyJ...`
5. Copy everything after `access_token=` until the next `&`
6. **This is your TRIVIA_USER_TOKEN** ✅

7. **Logout** (go to `https://YOUR_DOMAIN/v2/logout`)
8. Repeat steps 1-6 but **login as Trivia Manager** (`trivia-manager@test.com`)
9. **This is your TRIVIA_MANAGER_TOKEN** ✅

### Method 2: Using Auth0 Dashboard (Quick but not role-specific)

1. Go to **Applications → APIs → Trivia API**
2. Click **"Test"** tab
3. Click **"Copy Token"**
4. This token has ALL permissions (good for initial testing)

## Step 10: Update Your Project (2 minutes)

1. Open `backend/setup.sh`
2. Replace these values:

```bash
# Replace these with your actual values
export AUTH0_DOMAIN='dev-abc12345.us.auth0.com'  # Your actual domain
export ALGORITHMS='["RS256"]'                     # Keep as is
export API_AUDIENCE='trivia-api'                  # Keep as is

# Replace with actual tokens from Step 9
export TRIVIA_USER_TOKEN='eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI...'
export TRIVIA_MANAGER_TOKEN='eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI...'
```

3. Save the file

## Step 11: Test Locally (5 minutes)

```bash
cd backend

# Load environment variables
source setup.sh

# Run RBAC tests
python test_rbac.py

# If all tests pass, you're ready! ✅
```

Expected output:
```
..............
----------------------------------------------------------------------
Ran 14 tests in 3.124s

OK
```

## Step 12: Test with curl (Optional)

### Test 1: No auth should fail
```bash
curl http://localhost:5000/questions
```
Expected: `"authorization_header_missing"`

### Test 2: User token should work
```bash
curl http://localhost:5000/questions \
  -H "Authorization: Bearer $TRIVIA_USER_TOKEN"
```
Expected: List of questions

### Test 3: User cannot create (should fail)
```bash
curl -X POST http://localhost:5000/questions \
  -H "Authorization: Bearer $TRIVIA_USER_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"question":"Test","answer":"Test","category":"1","difficulty":1}'
```
Expected: `"Permission not found"` (403)

### Test 4: Manager can create
```bash
curl -X POST http://localhost:5000/questions \
  -H "Authorization: Bearer $TRIVIA_MANAGER_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"question":"Manager Test","answer":"Success","category":"1","difficulty":2}'
```
Expected: `"success": true, "created": <id>`

## ✅ Checklist

- [ ] Auth0 account created
- [ ] Trivia API created with identifier `trivia-api`
- [ ] 4 permissions added
- [ ] RBAC enabled
- [ ] 2 roles created (Trivia User, Trivia Manager)
- [ ] 2 test users created and assigned roles
- [ ] Test application created
- [ ] 2 JWT tokens generated
- [ ] `backend/setup.sh` updated with actual values
- [ ] RBAC tests pass (`python test_rbac.py`)

## 🎉 You're Done!

Once all tests pass, you're ready to deploy!

## Next: Deploy to Render

1. Push your code to GitHub
2. Go to https://render.com
3. Sign up with GitHub
4. Create new Web Service
5. Connect your repo
6. Render will auto-detect `render.yaml`
7. Add environment variables:
   ```
   AUTH0_DOMAIN=your-actual-domain.us.auth0.com
   ALGORITHMS=["RS256"]
   API_AUDIENCE=trivia-api
   ```
8. Deploy!

## Troubleshooting

### "Token expired"
Tokens expire after 24 hours. Generate new ones using Step 9.

### "Permission not found"
Check that:
1. User has correct role assigned
2. Role has correct permissions
3. RBAC is enabled in API settings

### "Invalid token"
Make sure you're copying the ENTIRE token (starts with `eyJ`)

---

**Need help? Check AUTH0_SETUP.md for detailed explanations.**
