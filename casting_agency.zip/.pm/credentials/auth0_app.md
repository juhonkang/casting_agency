Domain
dev-8607typd5q1j6mig.us.auth0.com
Client ID
HFDzwNkABHS817OOsBVf3gqEpwAqngoU
Client Secret
e4jP5vCySVc-A3ACmn73z8gICj8Qw02wlveYs7lZdUH48Ktwf75fkKjBaqQWSk0_


